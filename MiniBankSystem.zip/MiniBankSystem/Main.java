import java.io.*;
import java.lang.annotation.*;
import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.util.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface Id {
}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface Positive {
    String message() default "must be greater than zero";
}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface MaxLength {
    int value();
}

class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

class AccountNotFoundException extends Exception {
    public AccountNotFoundException(String message) {
        super(message);
    }
}

@FunctionalInterface
interface WithdrawRule {
    boolean canWithdraw(double balance, double amount);
}

class Transaction {
    private final String details;
    private final LocalDateTime time;

    public Transaction(String details) {
        this.details = details;
        this.time = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return time + " - " + details;
    }
}

abstract class BankAccount {
    @Id
    @MaxLength(20)
    private final String accountNumber;

    private final String holderName;

    @Positive
    private double balance;

    protected final List<Transaction> transactions = new ArrayList<>();

    public BankAccount(String accountNumber, String holderName, double balance) {
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.balance = balance;
        transactions.add(new Transaction("Account created"));
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getHolderName() {
        return holderName;
    }

    public double getBalance() {
        return balance;
    }

    protected void setBalance(double balance) {
        this.balance = balance;
    }

    public void deposit(double amount) {
        if (!Double.isFinite(amount) || amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive.");
        }

        balance += amount;
        transactions.add(new Transaction("Deposited Rs. " + amount));
    }

    public abstract void withdraw(double amount)
            throws InsufficientFundsException;

    public void addTransaction(String message) {
        transactions.add(new Transaction(message));
    }

    public void showTransactions() {
        if (transactions.isEmpty()) {
            System.out.println("No transactions found.");
            return;
        }

        for (Transaction transaction : transactions) {
            System.out.println(transaction);
        }
    }

    @Override
    public String toString() {
        return "Account: " + accountNumber
                + " | Holder: " + holderName
                + " | Balance: Rs. " + balance
                + " | Type: " + getClass().getSimpleName();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof BankAccount)) return false;
        BankAccount other = (BankAccount) obj;
        return accountNumber.equals(other.accountNumber);
    }

    @Override
    public int hashCode() {
        return accountNumber.hashCode();
    }
}

class SavingsAccount extends BankAccount {
    private static final double MIN_BALANCE = 100;

    private final WithdrawRule rule =
            (balance, amount) -> amount > 0 && balance - amount >= MIN_BALANCE;

    public SavingsAccount(String number, String name, double balance) {
        super(number, name, balance);
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundsException {
        if (!Double.isFinite(amount) || amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive.");
        }
        if (getBalance() < amount) {
            throw new InsufficientFundsException("Insufficient balance.");
        }
        if (!rule.canWithdraw(getBalance(), amount)) {
            throw new InsufficientFundsException(
                    "Minimum balance of Rs. 100 required.");
        }

        setBalance(getBalance() - amount);
        addTransaction("Withdrawn Rs. " + amount);
    }
}

class CurrentAccount extends BankAccount {
    public CurrentAccount(String number, String name, double balance) {
        super(number, name, balance);
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundsException {
        if (!Double.isFinite(amount) || amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive.");
        }
        if (amount > getBalance()) {
            throw new InsufficientFundsException("Insufficient balance.");
        }

        setBalance(getBalance() - amount);
        addTransaction("Withdrawn Rs. " + amount);
    }
}

class Repository<T extends BankAccount> {
    private final Map<String, T> accounts = new LinkedHashMap<>();

    public void save(T account) {
        accounts.put(account.getAccountNumber(), account);
    }

    public T findById(String id) {
        return accounts.get(id);
    }

    public Collection<T> findAll() {
        return accounts.values();
    }

    public boolean exists(String id) {
        return accounts.containsKey(id);
    }

    public void delete(String id) {
        accounts.remove(id);
    }
}

class AnnotationValidator {
    public static String[] validate(Object obj) {
        List<String> errors = new ArrayList<>();
        Class<?> type = obj.getClass();

        while (type != null && type != Object.class) {
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);

                try {
                    Object value = field.get(obj);

                    if (field.isAnnotationPresent(Id.class)
                            && (value == null || value.toString().isBlank())) {
                        errors.add(field.getName() + " must not be blank.");
                    }

                    if (field.isAnnotationPresent(Positive.class)) {
                        Positive annotation = field.getAnnotation(Positive.class);
                        if (value instanceof Number
                                && ((Number) value).doubleValue() < 0) {
                            errors.add(field.getName() + " " + annotation.message());
                        }
                    }

                    if (field.isAnnotationPresent(MaxLength.class)) {
                        MaxLength annotation = field.getAnnotation(MaxLength.class);
                        if (value instanceof String
                                && ((String) value).length() > annotation.value()) {
                            errors.add(field.getName() + " exceeds maximum length "
                                    + annotation.value());
                        }
                    }
                } catch (IllegalAccessException e) {
                    errors.add("Cannot access " + field.getName());
                }
            }
            type = type.getSuperclass();
        }

        return errors.toArray(new String[0]);
    }
}

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final Repository<BankAccount> repository = new Repository<>();
    private static final String FILE_NAME = "bank_accounts.txt";

    public static void main(String[] args) {
        loadAccounts();
        int choice = 0;

        do {
            System.out.println("\n===== MINI BANK SYSTEM =====");
            System.out.println("1. Create Account");
            System.out.println("2. View All Accounts");
            System.out.println("3. Check Balance");
            System.out.println("4. Deposit Money");
            System.out.println("5. Withdraw Money");
            System.out.println("6. Transfer Money");
            System.out.println("7. Transaction History");
            System.out.println("8. Delete Account");
            System.out.println("9. Validate Account");
            System.out.println("10. Save and Exit");
            System.out.print("Enter choice: ");

            try {
                choice = Integer.parseInt(sc.nextLine().trim());

                switch (choice) {
                    case 1 -> createAccount();
                    case 2 -> viewAccounts();
                    case 3 -> checkBalance();
                    case 4 -> deposit();
                    case 5 -> withdraw();
                    case 6 -> transfer();
                    case 7 -> history();
                    case 8 -> deleteAccount();
                    case 9 -> validateAccount();
                    case 10 -> {
                        saveAccounts();
                        System.out.println("Data saved. Goodbye!");
                    }
                    default -> System.out.println("Invalid choice.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                choice = 0;
            } catch (AccountNotFoundException | InsufficientFundsException e) {
                System.out.println(e.getMessage());
                choice = 0;
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
                choice = 0;
            }
        } while (choice != 10);

        sc.close();
    }

    private static void createAccount() {
        System.out.print("Account number: ");
        String id = sc.nextLine().trim();
        System.out.print("Account holder name: ");
        String name = sc.nextLine().trim();
        System.out.print("Opening balance: ");
        double balance = Double.parseDouble(sc.nextLine().trim());
        System.out.print("Type (1 Savings / 2 Current): ");
        int type = Integer.parseInt(sc.nextLine().trim());

        if (id.isBlank() || name.isBlank()) {
            throw new IllegalArgumentException("Account number and name are required.");
        }
        if (repository.exists(id)) {
            throw new IllegalArgumentException("Account number already exists.");
        }
        if (!Double.isFinite(balance) || balance <= 0) {
            throw new IllegalArgumentException("Opening balance must be positive.");
        }

        BankAccount account;
        if (type == 1) {
            if (balance < 100) {
                throw new IllegalArgumentException(
                        "Savings account requires Rs. 100 minimum.");
            }
            account = new SavingsAccount(id, name, balance);
        } else if (type == 2) {
            account = new CurrentAccount(id, name, balance);
        } else {
            throw new IllegalArgumentException("Invalid account type.");
        }

        String[] errors = AnnotationValidator.validate(account);
        if (errors.length > 0) {
            for (String error : errors) System.out.println(error);
            return;
        }

        repository.save(account);
        System.out.println("Account created successfully!");
    }

    private static BankAccount getAccount(String id) throws AccountNotFoundException {
        BankAccount account = repository.findById(id);
        if (account == null) {
            throw new AccountNotFoundException("Account not found: " + id);
        }
        return account;
    }

    private static void viewAccounts() {
        if (repository.findAll().isEmpty()) {
            System.out.println("No accounts available.");
            return;
        }
        for (BankAccount account : repository.findAll()) {
            System.out.println(account);
        }
    }

    private static void checkBalance() throws AccountNotFoundException {
        BankAccount account = getAccount(readId());
        System.out.println("Current balance: Rs. " + account.getBalance());
    }

    private static void deposit() throws AccountNotFoundException {
        BankAccount account = getAccount(readId());
        System.out.print("Amount to deposit: ");
        double amount = Double.parseDouble(sc.nextLine().trim());
        account.deposit(amount);
        System.out.println("Deposit successful.");
    }

    private static void withdraw()
            throws AccountNotFoundException, InsufficientFundsException {
        BankAccount account = getAccount(readId());
        System.out.print("Amount to withdraw: ");
        double amount = Double.parseDouble(sc.nextLine().trim());
        account.withdraw(amount);
        System.out.println("Withdrawal successful.");
    }

    private static void transfer()
            throws AccountNotFoundException, InsufficientFundsException {
        System.out.print("From account: ");
        BankAccount from = getAccount(sc.nextLine().trim());
        System.out.print("To account: ");
        BankAccount to = getAccount(sc.nextLine().trim());

        if (from.equals(to)) {
            throw new IllegalArgumentException("Cannot transfer to the same account.");
        }

        System.out.print("Transfer amount: ");
        double amount = Double.parseDouble(sc.nextLine().trim());
        if (!Double.isFinite(amount) || amount <= 0) {
            throw new IllegalArgumentException("Transfer amount must be positive.");
        }

        from.withdraw(amount);
        try {
            to.deposit(amount);
        } catch (RuntimeException e) {
            from.deposit(amount);
            throw e;
        }

        from.addTransaction("Transfer to " + to.getAccountNumber() + ": Rs. " + amount);
        to.addTransaction("Transfer from " + from.getAccountNumber() + ": Rs. " + amount);
        System.out.println("Transfer successful.");
    }

    private static void history() throws AccountNotFoundException {
        getAccount(readId()).showTransactions();
    }

    private static void deleteAccount() throws AccountNotFoundException {
        String id = readId();
        getAccount(id);
        repository.delete(id);
        System.out.println("Account deleted.");
    }

    private static void validateAccount() throws AccountNotFoundException {
        BankAccount account = getAccount(readId());
        String[] errors = AnnotationValidator.validate(account);
        if (errors.length == 0) {
            System.out.println("Account is valid.");
        } else {
            for (String error : errors) System.out.println(error);
        }
    }

    private static String readId() {
        System.out.print("Enter account number: ");
        return sc.nextLine().trim();
    }

    private static void saveAccounts() {
        try (PrintWriter out = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (BankAccount account : repository.findAll()) {
                out.println(account.getAccountNumber() + "|"
                        + account.getHolderName() + "|"
                        + account.getBalance() + "|"
                        + account.getClass().getSimpleName());
            }
        } catch (IOException e) {
            System.out.println("Could not save data: " + e.getMessage());
        }
    }

    private static void loadAccounts() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\|", -1);
                if (p.length != 4) continue;

                String id = p[0];
                String name = p[1];
                double balance = Double.parseDouble(p[2]);
                BankAccount account;

                if (p[3].equals("SavingsAccount")) {
                    account = new SavingsAccount(id, name, balance);
                } else if (p[3].equals("CurrentAccount")) {
                    account = new CurrentAccount(id, name, balance);
                } else {
                    continue;
                }
                repository.save(account);
            }
            System.out.println("Saved accounts loaded.");
        } catch (IOException | NumberFormatException e) {
            System.out.println("Could not load saved data.");
        }
    }
}
